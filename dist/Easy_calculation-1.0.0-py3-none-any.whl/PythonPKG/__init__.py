
def add(a,b):
    return a+b

def sub(a,b):
    return a-b

def multi(a,b):
    return a*b

def div(a,b):
    return a/b

def negadd(a,b):
    return -a + -b 

def negsub(a,b):
    return -a - -b 

def negmulti(a,b):
    return -a * -b 

def negdiv(a,b):
    return -a / -b





                   